﻿namespace GpsGame.Infrastructure;

public class Class1
{

}
