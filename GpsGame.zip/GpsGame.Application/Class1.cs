﻿namespace GpsGame.Application;

public class Class1
{

}
